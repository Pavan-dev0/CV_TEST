"""End-to-end pipeline: image -> OCR -> fields -> question -> scoring -> feedback -> report."""
from __future__ import annotations

from dataclasses import asdict
from datetime import datetime

from .data_loader import Dataset
from .feedback import generate_feedback
from .lookup import identify_question
from .ocr import parse_fields, run_ocr
from .scorer import Options, evaluate_answer


def read_sheet(image, engine: str) -> dict:
    """Steps 1-2: OCR the image and split it into fields."""
    ocr, stages = run_ocr(image, engine)
    fields = parse_fields(ocr.text)
    return {"ocr": ocr, "stages": stages, "fields": fields}


def evaluate_fields(fields: dict, dataset: Dataset, options: Options | None = None) -> dict:
    """Steps 3-7 on (possibly faculty-corrected) text fields."""
    q = identify_question(dataset, fields.get("question_no", ""), fields.get("question", ""))
    if q.get("reference_answer") is None:
        return {"question": q, "evaluation": None, "feedback": None}
    rubric = dataset.rubric_for(q["question_id"])
    corpus = dataset.questions["reference_answer"].tolist()
    others = dataset.questions.to_dict("records")
    ev = evaluate_answer(fields.get("answer", ""), q, rubric, corpus, others, options)
    if q.get("note"):
        ev.flags.insert(0, q["note"])
    fb = generate_feedback(ev, q["reference_answer"])
    return {"question": q, "evaluation": ev, "feedback": fb}


def report_row(fields: dict, result: dict, final_marks=None, reviewer: str = "", remarks: str = "") -> dict:
    """Flat record for the CSV log of evaluations."""
    ev, fb, q = result["evaluation"], result["feedback"], result["question"]
    return {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "student_id": fields.get("student_id", ""),
        "question_id": q.get("question_id"),
        "student_answer_ocr": fields.get("answer", ""),
        "max_marks": ev.max_marks if ev else None,
        "preliminary_marks": ev.total if ev else None,
        "final_marks": final_marks,
        "category": ev.category if ev else "",
        "tfidf_similarity": ev.tfidf_similarity if ev else None,
        "semantic_similarity": ev.semantic_similarity if ev else None,
        "concepts_covered": "; ".join(fb["covered"]) if fb else "",
        "concepts_partial": "; ".join(fb["partial"]) if fb else "",
        "concepts_missing": "; ".join(fb["missing"]) if fb else "",
        "feedback": fb["summary"] if fb else "",
        "suggestion": fb["suggestion"] if fb else "",
        "flags": " | ".join(ev.flags) if ev else "",
        "reviewed_by": reviewer,
        "faculty_remarks": remarks,
        "status": "Reviewed" if reviewer else "Preliminary - pending faculty review",
    }


def concept_table(result: dict) -> list[dict]:
    ev = result["evaluation"]
    return [{"Expected concept": c.concept,
             "Identified?": {"covered": "Yes", "partial": "Partly", "negated": "Negated"}.get(c.status, "No"),
             "Evidence in answer": c.evidence, "Match type": c.method,
             "Marks": c.marks, "Awarded": c.awarded} for c in ev.concepts] if ev else []


__all__ = ["read_sheet", "evaluate_fields", "report_row", "concept_table", "Options", "asdict"]
