"""Step 3: identify the question in questions.csv by ID, with a text-match fallback."""
from __future__ import annotations

from difflib import SequenceMatcher

from .data_loader import Dataset, normalise_qid

try:
    from rapidfuzz import fuzz

    def _ratio(a: str, b: str) -> float:
        return fuzz.token_set_ratio(a, b) / 100
except ImportError:  # pragma: no cover
    def _ratio(a: str, b: str) -> float:
        return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def identify_question(dataset: Dataset, question_no: str, question_text: str = "") -> dict:
    """Returns {question_id, question, reference_answer, max_marks, method, confidence, note}."""
    qid = normalise_qid(question_no) if question_no else None
    by_id = dataset.question(qid) if qid else None

    best, best_score = None, 0.0
    if question_text:
        for _, row in dataset.questions.iterrows():
            s = _ratio(question_text, row["question"])
            if s > best_score:
                best, best_score = row.to_dict(), s

    if by_id:
        note = ""
        if question_text and best and best["question_id"] != qid and best_score >= 0.85:
            note = (f"Question text looks more like {best['question_id']} "
                    f"({best_score:.0%} match) - please confirm the question number.")
        return {**by_id, "method": "question ID", "confidence": 1.0, "note": note}
    if best and best_score >= 0.6:
        return {**best, "method": "question text match", "confidence": best_score,
                "note": f"Question ID '{question_no or '?'}' not found; matched by question text."}
    return {"question_id": qid, "question": None, "reference_answer": None, "max_marks": None,
            "method": "not found", "confidence": 0.0,
            "note": "Question could not be identified. Correct the question number and re-run."}
