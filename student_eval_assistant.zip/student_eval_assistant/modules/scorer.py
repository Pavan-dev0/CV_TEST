"""Steps 5-6: compare the answer with the reference and award rubric marks.

Marks come ONLY from rubric concepts. Similarity scores are shown for information and
used to flag off-topic answers; they never award marks on their own.

Concept matching, per rubric row:
  1. Split alternatives ("model learns / trains" -> "model learns" | "trains") and add
     abbreviations ("artificial intelligence" <-> "ai").
  2. Pass 1 - exact matches (same word stem) for every concept.
  3. Pass 2 - synonym / OCR-typo matches, but a word already used as exact evidence for
     another concept cannot be reused (stops one phrase earning two marks).
  4. Optional pass 3 - sentence-embedding similarity, if sentence-transformers is installed.
  A concept with 1 word needs that word; with 2 words needs both; with 3+ words needs its
  first key word plus two-thirds of the rest - all inside one sentence, and not negated.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .preprocess import (ABBREVIATIONS, NEGATIONS, STOP_WORDS, lemma, preprocess, sentences, stem,
                         synonyms, tokenize)

try:
    from rapidfuzz.distance import Levenshtein

    def _typo_ok(a: str, b: str) -> bool:
        return Levenshtein.normalized_similarity(a, b) >= (0.75 if min(len(a), len(b)) >= 8 else 0.83)
except ImportError:  # pragma: no cover
    from difflib import SequenceMatcher

    def _typo_ok(a: str, b: str) -> bool:
        return SequenceMatcher(None, a, b).ratio() >= (0.75 if min(len(a), len(b)) >= 8 else 0.83)

# Fixed terms whose words must not be read as synonyms on their own.
COMPOUNDS = {("machine", "learning"), ("deep", "learning"), ("neural", "network"), ("natural", "language"),
             ("computer", "vision"), ("data", "science"), ("supervised", "learning")}

# Words too generic to be the "key" word of a concept phrase.
GENERIC = {"human", "language", "data", "information", "system", "text", "image", "images", "model",
           "value", "values", "new", "small", "smaller"}


@dataclass
class Options:
    partial_marks: bool = False        # half marks when a concept is partly present
    use_semantic: bool = True          # use sentence-transformers if it is installed
    semantic_full: float = 0.62
    semantic_partial: float = 0.48
    relevance_gate: bool = True        # 0 marks for answers that are clearly off-topic


@dataclass
class ConceptResult:
    concept: str
    marks: float
    status: str = "missing"            # covered | partial | missing | negated
    awarded: float = 0.0
    evidence: str = ""
    method: str = ""
    detail: str = ""


@dataclass
class Evaluation:
    concepts: list[ConceptResult]
    total: float
    max_marks: float
    tfidf_similarity: float
    semantic_similarity: float | None
    category: str
    flags: list[str] = field(default_factory=list)
    preprocessing: dict = field(default_factory=dict)

    @property
    def covered(self) -> list[ConceptResult]:
        return [c for c in self.concepts if c.status == "covered"]

    @property
    def partial(self) -> list[ConceptResult]:
        return [c for c in self.concepts if c.status == "partial"]

    @property
    def missing(self) -> list[ConceptResult]:
        return [c for c in self.concepts if c.status in ("missing", "negated")]


# ----------------------------------------------------------------------------- semantic model (optional)

_MODEL = "unloaded"


def get_semantic_model():
    """Returns a SentenceTransformer or None (not installed / no internet for first download)."""
    global _MODEL
    if _MODEL == "unloaded":
        try:
            from sentence_transformers import SentenceTransformer
            _MODEL = SentenceTransformer("all-MiniLM-L6-v2")
        except Exception:
            _MODEL = None
    return _MODEL


def _semantic(a: list[str], b: list[str]) -> np.ndarray | None:
    model = get_semantic_model()
    if model is None or not a or not b:
        return None
    ea = model.encode(a, normalize_embeddings=True)
    eb = model.encode(b, normalize_embeddings=True)
    return ea @ eb.T


# ----------------------------------------------------------------------------- answer analysis


@dataclass
class _Tok:
    word: str
    stem: str
    pos: int          # index among all tokens (for negation look-back)
    sent: int         # sentence index
    usable: bool = True
    syn_ok: bool = True     # False for words inside fixed terms such as "machine learning"


def _answer_tokens(answer: str, question: str) -> list[_Tok]:
    q_stems = {stem(t) for t in tokenize(question)}
    q_abbr = {ab for long, ab in ABBREVIATIONS.items() if long in question.lower()}
    q_abbr |= set(re.findall(r"\(([a-z]{2,6})\)", question.lower()))     # "(CNN)" in the question
    toks: list[_Tok] = []
    pos = 0
    for si, sent in enumerate(sentences(answer) or [answer]):
        for w in tokenize(sent):
            toks.append(_Tok(w, stem(w), pos, si))
            pos += 1
    for a, b in zip(toks, toks[1:]):
        if (a.word, b.word) in COMPOUNDS:
            a.syn_ok = b.syn_ok = False
    # Loophole guard: the answer's leading subject usually just repeats the question term
    # ("Image segmentation divides ...", "Tokenization splits ..."). Those words are not evidence.
    stripped = 0
    for t in toks:
        if t.sent > 0:
            break
        if t.word in STOP_WORDS and t.word not in NEGATIONS:
            if stripped:            # "NLP is used to process ..." - the subject ends at the first verb
                break
            continue
        if t.stem in q_stems or t.word in q_abbr:
            t.usable = False
            stripped += 1
            continue
        break
    return toks


def _alternatives(concept: str, extra_keywords: str = "") -> list[list[str]]:
    """'Artificial Intelligence / AI' -> [['artificial','intelligence'], ['ai']]"""
    raw = re.split(r"\s*/\s*|\s*\|\s*|\s+or\s+", re.sub(r"[()]", "/", concept))
    raw += [k for k in re.split(r"[;,|]", extra_keywords or "") if k.strip()]
    phrases = [p.strip().lower() for p in raw if p.strip()]
    for phrase in list(phrases):                       # add abbreviation <-> long-form variants
        for long, short in ABBREVIATIONS.items():
            variant = None
            if long in phrase:
                variant = phrase.replace(long, short)
            elif re.search(rf"\b{short}\b", phrase):
                variant = re.sub(rf"\b{short}\b", long, phrase)
            if variant and variant not in phrases:
                phrases.append(variant)
    alts = []
    for phrase in phrases:
        words = [w for w in tokenize(phrase) if w not in STOP_WORDS]
        if words and words not in alts:
            alts.append(words)
    return alts


def _key_index(words: list[str]) -> int:
    for i, w in enumerate(words):
        if w not in GENERIC:
            return i
    return 0


def _find(word: str, toks: list[_Tok], allow_syn: bool, blocked: set[int]) -> list[tuple[_Tok, str]]:
    s = stem(word)
    hits = []
    for t in toks:
        if not t.usable:
            continue
        if t.stem == s:
            hits.append((t, "exact"))
        elif allow_syn and t.syn_ok and t.pos not in blocked:
            if t.stem in synonyms(word) or stem(t.word) in synonyms(word):
                hits.append((t, "synonym"))
            elif len(word) >= 6 and len(t.word) >= 6 and word[0] == t.word[0] and _typo_ok(word, t.word):
                hits.append((t, "OCR-typo"))
    return hits


def _negated(t: _Tok, toks: list[_Tok]) -> bool:
    return any(o.word in NEGATIONS for o in toks if o.sent == t.sent and t.pos - 3 <= o.pos < t.pos)


def _match_alt(words: list[str], toks: list[_Tok], allow_syn: bool, blocked: set[int]) -> dict:
    """Best sentence-level match of one alternative phrase."""
    n = len(words)
    key = _key_index(words)
    need = 1 if n == 1 else (2 if n == 2 else math.ceil(2 * n / 3))
    hits = {i: _find(w, toks, allow_syn, blocked) for i, w in enumerate(words)}
    best = {"level": 0, "found": 0, "tokens": [], "method": "", "negated": False}
    for sent in sorted({t.sent for t in toks}):
        found, used, methods = 0, [], set()
        key_tok = None
        for i in range(n):
            in_sent = [(t, m) for t, m in hits[i] if t.sent == sent]
            if in_sent:
                t, m = sorted(in_sent, key=lambda x: x[1] != "exact")[0]
                found += 1
                used.append(t)
                methods.add(m)
                if i == key:
                    key_tok = t
        if found == 0:
            continue
        negated = key_tok is not None and _negated(key_tok, toks)
        if key_tok is not None and found >= need and not negated:
            level = 2
        elif found >= max(1, n / 2) or (key_tok is not None and n == 2):
            level = 1
        else:
            level = 0
        method = "exact" if methods == {"exact"} else "+".join(sorted(methods - {"exact"}))
        cand = {"level": level, "found": found, "tokens": used, "method": method, "negated": negated}
        if (level, found) > (best["level"], best["found"]):
            best = cand
    return best


# ----------------------------------------------------------------------------- main entry points


def overall_similarity(answer: str, reference: str, corpus: list[str]) -> tuple[float, float | None]:
    """TF-IDF cosine (fitted on all reference answers for meaningful IDF) + optional semantic cosine."""
    clean = [preprocess(t)["clean_string"] for t in corpus + [reference, answer]]
    vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True).fit(clean)
    m = vec.transform(clean[-2:])
    tfidf = float(cosine_similarity(m[0], m[1])[0, 0]) if m.nnz else 0.0
    sem = _semantic([answer], [reference])
    return tfidf, (float(sem[0, 0]) if sem is not None else None)


def evaluate_answer(answer: str, question: dict, rubric_rows, reference_corpus: list[str],
                    other_questions: list[dict] | None = None, options: Options | None = None) -> Evaluation:
    opts = options or Options()
    question_text = question.get("question") or ""
    reference = question.get("reference_answer") or ""
    max_marks = float(question.get("max_marks") or 0)
    flags: list[str] = []
    pre = preprocess(answer)

    results = [ConceptResult(concept=r["concept"], marks=float(r["marks"])) for _, r in rubric_rows.iterrows()]
    if not answer.strip() or len(pre["without_stopwords"]) == 0:
        return Evaluation(results, 0.0, max_marks, 0.0, None, "Irrelevant",
                          ["No answer text was found. Check the image or the OCR output."], pre)

    toks = _answer_tokens(answer, question_text)
    alts_per = [_alternatives(r["concept"], r.get("keywords", "")) for _, r in rubric_rows.iterrows()]
    best: list[dict] = [{"level": 0, "found": 0, "tokens": [], "method": "", "negated": False}] * len(results)

    # pass 1: exact evidence
    for i, alts in enumerate(alts_per):
        for words in alts:
            m = _match_alt(words, toks, allow_syn=False, blocked=set())
            if (m["level"], m["found"]) > (best[i]["level"], best[i]["found"]):
                best[i] = m
    blocked = {t.pos for b in best if b["level"] == 2 for t in b["tokens"]}
    # pass 2: synonyms / OCR typos, without reusing another concept's exact evidence
    for i, alts in enumerate(alts_per):
        if best[i]["level"] == 2:
            continue
        own = {t.pos for t in best[i]["tokens"]}
        for words in alts:
            m = _match_alt(words, toks, allow_syn=True, blocked=blocked - own)
            if (m["level"], m["found"]) > (best[i]["level"], best[i]["found"]):
                best[i] = m

    sents = sentences(answer) or [answer]
    for i, (res, b) in enumerate(zip(results, best)):
        if b["tokens"]:
            res.evidence = ", ".join(dict.fromkeys(t.word for t in b["tokens"]))
        if b["negated"]:
            res.status, res.method = "negated", b["method"]
            res.detail = "Concept words appear but are negated (e.g. 'not')."
        elif b["level"] == 2:
            res.status, res.method = "covered", b["method"]
        elif b["level"] == 1:
            res.status, res.method = "partial", b["method"]
            res.detail = "Only part of this concept is mentioned."

    # pass 3: semantic similarity for anything still not covered
    if opts.use_semantic:
        pending = [i for i, r in enumerate(results) if r.status in ("missing", "partial")]
        sims = _semantic([" ".join(alts_per[i][0]) for i in pending], sents) if pending else None
        if sims is not None:
            for row, i in enumerate(pending):
                j = int(np.argmax(sims[row]))
                s = float(sims[row, j])
                if s >= opts.semantic_full:
                    results[i].status, results[i].method = "covered", f"semantic ({s:.2f})"
                    results[i].evidence, results[i].detail = sents[j], ""
                elif s >= opts.semantic_partial and results[i].status == "missing":
                    results[i].status, results[i].method = "partial", f"semantic ({s:.2f})"
                    results[i].evidence = sents[j]
                    results[i].detail = "Similar meaning, but not clearly stated."

    for r in results:
        r.awarded = r.marks if r.status == "covered" else (r.marks / 2 if r.status == "partial" and opts.partial_marks else 0.0)
    total = min(sum(r.awarded for r in results), max_marks)

    # relevance check (flags / gate - never adds marks)
    tfidf, sem = overall_similarity(answer, reference, reference_corpus)
    n_cov = sum(r.status == "covered" for r in results)
    better = None
    for oq in other_questions or []:
        if oq["question_id"] == question.get("question_id"):
            continue
        t_other, _ = overall_similarity(answer, oq["reference_answer"], reference_corpus)
        if t_other > tfidf + 0.1 and (better is None or t_other > better[1]):
            better = (oq["question_id"], t_other)
    off_topic = n_cov <= 1 and (tfidf < 0.2 or better is not None)
    if better:
        flags.append(f"This answer is closer to the reference answer of {better[0]} - "
                     f"the student may have answered a different question.")
    if off_topic and opts.relevance_gate and total > 0:
        flags.append(f"Answer looks unrelated to the question (only {n_cov} concept word matched, "
                     f"TF-IDF similarity {tfidf:.2f}); {total:g} mark(s) withheld. Faculty can override.")
        total = 0.0
        for r in results:
            r.awarded = 0.0
    content = pre["without_stopwords"]
    all_tokens = tokenize(answer)
    if n_cov >= 3 and len(all_tokens) >= 4 and len(all_tokens) - len(content) <= 1:
        flags.append("Answer looks like a list of keywords without explanation - please review.")
    if any(r.status == "negated" for r in results):
        flags.append("Some concepts appear in a negative sentence - please review.")

    ratio = total / max_marks if max_marks else 0
    category = "Relevant" if ratio >= 0.7 else ("Partially relevant" if ratio >= 0.2 else "Irrelevant")
    return Evaluation(results, round(total, 2), max_marks, round(tfidf, 3),
                      None if sem is None else round(sem, 3), category, flags, pre)
