"""Step 7: turn the concept results into short, specific feedback."""
from __future__ import annotations

import re

from .scorer import Evaluation


def _join(items: list[str]) -> str:
    items = [i for i in items if i]
    if len(items) <= 1:
        return "".join(items)
    return ", ".join(items[:-1]) + " and " + items[-1]


def _pretty(concept: str) -> str:
    return re.sub(r"\s*/\s*", " / ", concept.strip())


def generate_feedback(ev: Evaluation, reference_answer: str = "") -> dict:
    covered = [_pretty(c.concept) for c in ev.covered]
    partial = [_pretty(c.concept) for c in ev.partial]
    missing = [_pretty(c.concept) for c in ev.missing]
    ratio = ev.total / ev.max_marks if ev.max_marks else 0

    if ratio >= 0.9:
        headline = "Excellent answer."
    elif ratio >= 0.7:
        headline = "Good answer, nearly complete."
    elif ratio >= 0.4:
        headline = "Partially correct answer."
    elif ratio > 0:
        headline = "The answer needs significant improvement."
    else:
        headline = "The answer does not address the expected concepts."

    parts = [headline]
    if covered:
        parts.append(f"You correctly explained {_join(covered)}.")
    if partial:
        parts.append(f"You touched on {_join(partial)}, but did not state it clearly.")
    if missing:
        parts.append(f"To make the answer complete, also include {_join(missing)}.")
    elif not partial:
        parts.append("All expected concepts are covered.")
    if ratio < 0.4 and reference_answer:
        parts.append("Start from the definition and then explain what it does and why it is used.")

    suggestion = ""
    if missing:
        suggestion = (f"Add one or two sentences on {_join(missing[:2])}"
                      + (" and the remaining points" if len(missing) > 2 else "") + ".")
    elif partial:
        suggestion = f"State {_join(partial)} explicitly instead of implying it."
    else:
        suggestion = "Add a short example to make the answer even stronger."

    return {"covered": covered, "partial": partial, "missing": missing,
            "summary": " ".join(parts), "suggestion": suggestion, "flags": ev.flags}
