"""Load and validate the faculty-provided CSV files.

Column names in hackathon datasets vary ("Question ID", "question_id", "QID"),
so every column is resolved from a list of accepted aliases.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import pandas as pd


def _norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


ALIASES = {
    "question_id": ["questionid", "qid", "questionno", "questionnumber", "qno", "question_id", "id"],
    "question": ["question", "questiontext", "questions"],
    "reference_answer": ["referenceanswer", "referenceanswersummary", "modelanswer", "answerkey",
                         "expectedanswer", "reference", "answer"],
    "max_marks": ["maxmarks", "maximummarks", "totalmarks", "marks", "max"],
    "concept": ["expectedconcept", "conceptorexpectedpoint", "concept", "expectedpoint", "concepts", "keyconcept", "rubricitem", "criteria", "criterion"],
    "concept_marks": ["marks", "conceptmarks", "mark", "score", "weight", "points"],
    "keywords": ["keywords", "synonyms", "alternatives", "aliases"],
    "student_id": ["studentid", "sid", "rollno", "rollnumber", "student"],
    "student_answer": ["studentanswer", "answer", "answertext", "response"],
    "expected_marks": ["expectedmarks", "samplemarks", "expectedscore", "marksawarded", "expected", "marks"],
    "image": ["answerimage", "image", "imagefile", "imagename", "filename", "file", "imagepath"],
}


class DataError(Exception):
    """Raised when a CSV file is missing required columns or has bad values."""


def _resolve(df: pd.DataFrame, key: str, required: bool = True, exclude: tuple = ()) -> str | None:
    cols = {_norm(c): c for c in df.columns if c not in exclude}
    for alias in ALIASES[key]:                 # 1) exact name
        if alias in cols:
            return cols[alias]
    for alias in ALIASES[key]:                 # 2) name contains the alias ("concept_or_expected_point")
        if len(alias) >= 4:
            for n, c in cols.items():
                if alias in n:
                    return c
    if required:
        raise DataError(f"Column for '{key}' not found. Available columns: {list(df.columns)}")
    return None


def normalise_qid(raw) -> str | None:
    """'Q1', 'q.1', 'Question 1', '1', 'Ql' (OCR) -> 'Q1'."""
    if raw is None or (isinstance(raw, float) and pd.isna(raw)):
        return None
    text = str(raw).strip()
    text = re.sub(r"(?i)^(question|ques|qn|q)\s*(no\.?|number)?\s*[.:\-#]?\s*", "", text)
    # common OCR confusions in digits
    text = text.translate(str.maketrans({"l": "1", "I": "1", "|": "1", "i": "1", "O": "0", "o": "0",
                                         "S": "5", "s": "5", "B": "8", "Z": "2", "z": "2"}))
    m = re.search(r"\d+", text)
    return f"Q{int(m.group())}" if m else None


def normalise_sid(raw) -> str:
    return re.sub(r"\s+", "", str(raw)).upper() if raw is not None else ""


@dataclass
class Dataset:
    questions: pd.DataFrame            # question_id, question, reference_answer, max_marks
    rubric: pd.DataFrame               # question_id, concept, marks, keywords
    student_answers: pd.DataFrame | None = None   # validation only
    warnings: list[str] = field(default_factory=list)

    def question(self, qid: str) -> dict | None:
        row = self.questions[self.questions["question_id"] == qid]
        return None if row.empty else row.iloc[0].to_dict()

    def rubric_for(self, qid: str) -> pd.DataFrame:
        return self.rubric[self.rubric["question_id"] == qid].reset_index(drop=True)


def load_questions(src) -> pd.DataFrame:
    df = pd.read_csv(src, encoding="utf-8-sig", encoding_errors="replace")
    df.columns = [str(c).strip() for c in df.columns]
    qid = _resolve(df, "question_id")
    q = _resolve(df, "question", exclude=(qid,))
    ref = _resolve(df, "reference_answer", exclude=(qid, q))
    mx = _resolve(df, "max_marks", exclude=(qid, q, ref))
    out = pd.DataFrame({
        "question_id": df[qid].map(normalise_qid),
        "question": df[q].astype(str).str.strip(),
        "reference_answer": df[ref].astype(str).str.strip(),
        "max_marks": pd.to_numeric(df[mx], errors="coerce"),
    })
    if out["question_id"].isna().any():
        raise DataError("questions.csv: some Question IDs could not be read.")
    if out["max_marks"].isna().any():
        raise DataError("questions.csv: some Max marks are not numbers.")
    return out


def load_rubric(src) -> pd.DataFrame:
    """Accepts long format: one row per (question, concept, marks)."""
    df = pd.read_csv(src, encoding="utf-8-sig", encoding_errors="replace")
    df.columns = [str(c).strip() for c in df.columns]
    qid = _resolve(df, "question_id")
    concept = _resolve(df, "concept", exclude=(qid,))
    marks = _resolve(df, "concept_marks", exclude=(qid, concept))
    kw = _resolve(df, "keywords", required=False, exclude=(qid, concept, marks))
    out = pd.DataFrame({
        "question_id": df[qid].map(normalise_qid),
        "concept": df[concept].astype(str).str.strip(),
        "marks": pd.to_numeric(df[marks], errors="coerce"),
        "keywords": df[kw].fillna("").astype(str) if kw else "",
    })
    # drop "Total" rows if the faculty file contains them
    out = out[~out["concept"].str.lower().isin({"total", "total marks", "nan", ""})]
    if out["marks"].isna().any():
        raise DataError("marking_rubric.csv: some concept marks are not numbers.")
    return out.reset_index(drop=True)


def load_student_answers(src) -> pd.DataFrame:
    df = pd.read_csv(src, encoding="utf-8-sig", encoding_errors="replace")
    df.columns = [str(c).strip() for c in df.columns]
    sid = _resolve(df, "student_id")
    qid = _resolve(df, "question_id", exclude=(sid,))
    ans = _resolve(df, "student_answer", exclude=(sid, qid))
    exp = _resolve(df, "expected_marks", required=False, exclude=(sid, qid, ans))
    img = _resolve(df, "image", required=False, exclude=(sid, qid, ans, exp))
    return pd.DataFrame({
        "student_id": df[sid].map(normalise_sid),
        "question_id": df[qid].map(normalise_qid),
        "answer": df[ans].astype(str),
        "expected_marks": pd.to_numeric(df[exp], errors="coerce") if exp else float("nan"),
        "image": df[img].astype(str) if img else "",
    })


def load_dataset(questions_src, rubric_src, student_answers_src=None) -> Dataset:
    questions = load_questions(questions_src)
    rubric = load_rubric(rubric_src)
    answers = load_student_answers(student_answers_src) if student_answers_src is not None else None
    warnings = []
    for _, q in questions.iterrows():
        r = rubric[rubric["question_id"] == q["question_id"]]
        if r.empty:
            warnings.append(f"{q['question_id']}: no rubric rows found.")
        elif abs(r["marks"].sum() - q["max_marks"]) > 1e-6:
            warnings.append(f"{q['question_id']}: rubric total {r['marks'].sum():g} "
                            f"differs from max marks {q['max_marks']:g}.")
    return Dataset(questions, rubric, answers, warnings)
