"""Intelligent Student Assignment Evaluation Assistant - core modules."""
