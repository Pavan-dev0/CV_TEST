"""Computer Vision + OCR: clean the answer-sheet image, read it, split it into fields.

Engines: EasyOCR (deep-learning, better on handwriting) or Tesseract (fast, no GPU).
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field

import cv2
import numpy as np
from PIL import Image

# ----------------------------------------------------------------------------- image preprocessing


def to_cv(image) -> np.ndarray:
    if isinstance(image, np.ndarray):
        return image
    if isinstance(image, (str, bytes, os.PathLike)) or hasattr(image, "read"):
        image = Image.open(image)
    return cv2.cvtColor(np.array(image.convert("RGB")), cv2.COLOR_RGB2BGR)


def deskew(gray: np.ndarray) -> tuple[np.ndarray, float]:
    """Straighten a slightly rotated scan using the angle of the text pixels."""
    inv = cv2.bitwise_not(gray)
    thr = cv2.threshold(inv, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    coords = np.column_stack(np.where(thr > 0))
    if len(coords) < 50:
        return gray, 0.0
    angle = cv2.minAreaRect(coords[:, ::-1].astype(np.float32))[-1]
    if angle > 45:
        angle -= 90
    if abs(angle) < 0.3 or abs(angle) > 15:      # ignore noise and implausible angles
        return gray, 0.0
    h, w = gray.shape
    m = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    out = cv2.warpAffine(gray, m, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    return out, angle


def preprocess_image(image) -> dict:
    """Grayscale -> upscale -> denoise -> deskew -> binarise. Returns every stage for display."""
    bgr = to_cv(image)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape
    if w < 1600:                                    # OCR works best at ~300 dpi equivalents
        scale = 1600 / w
        gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    denoised = cv2.fastNlMeansDenoising(gray, None, h=10, templateWindowSize=7, searchWindowSize=21)
    straight, angle = deskew(denoised)
    binary = cv2.adaptiveThreshold(straight, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY, 31, 15)
    return {"gray": straight, "binary": binary, "angle": angle}


# ----------------------------------------------------------------------------- OCR engines

_EASYOCR_READER = None


def get_easyocr_reader(gpu: bool = False):
    global _EASYOCR_READER
    if _EASYOCR_READER is None:
        import easyocr  # heavy import, done lazily
        _EASYOCR_READER = easyocr.Reader(["en"], gpu=gpu, verbose=False)
    return _EASYOCR_READER


def available_engines() -> list[str]:
    engines = []
    try:
        import easyocr  # noqa: F401
        engines.append("EasyOCR")
    except Exception:
        pass
    try:
        import pytesseract
        pytesseract.get_tesseract_version()
        engines.append("Tesseract")
    except Exception:
        pass
    return engines


@dataclass
class OCRResult:
    lines: list[tuple[str, float]]          # (line text, confidence 0-1)
    engine: str
    angle: float = 0.0
    low_conf_words: list[str] = field(default_factory=list)

    @property
    def text(self) -> str:
        return "\n".join(t for t, _ in self.lines)

    @property
    def mean_conf(self) -> float:
        return float(np.mean([c for _, c in self.lines])) if self.lines else 0.0


def _ocr_tesseract(img: np.ndarray) -> tuple[list[tuple[str, float]], list[str]]:
    import pytesseract
    data = pytesseract.image_to_data(img, config="--oem 3 --psm 4", output_type=pytesseract.Output.DICT)
    lines: dict[tuple, list[tuple[str, float]]] = {}
    low = []
    for i, word in enumerate(data["text"]):
        word = word.strip()
        conf = float(data["conf"][i])
        if not word or conf < 0:
            continue
        key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
        lines.setdefault(key, []).append((word, conf / 100))
        if conf < 60:
            low.append(word)
    out = [(" ".join(w for w, _ in ws), float(np.mean([c for _, c in ws]))) for _, ws in sorted(lines.items())]
    return out, low


def _ocr_easyocr(img: np.ndarray) -> tuple[list[tuple[str, float]], list[str]]:
    reader = get_easyocr_reader()
    results = reader.readtext(img, detail=1, paragraph=False)
    # group boxes into lines by vertical centre
    items = []
    for box, text, conf in results:
        ys = [p[1] for p in box]
        xs = [p[0] for p in box]
        items.append({"y": (min(ys) + max(ys)) / 2, "h": max(ys) - min(ys), "x": min(xs),
                      "text": text, "conf": float(conf)})
    items.sort(key=lambda d: d["y"])
    rows: list[list[dict]] = []
    for it in items:
        if rows and abs(it["y"] - np.mean([r["y"] for r in rows[-1]])) < 0.6 * max(it["h"], 10):
            rows[-1].append(it)
        else:
            rows.append([it])
    out, low = [], []
    for row in rows:
        row.sort(key=lambda d: d["x"])
        out.append((" ".join(r["text"] for r in row), float(np.mean([r["conf"] for r in row]))))
        low += [r["text"] for r in row if r["conf"] < 0.5]
    return out, low


def run_ocr(image, engine: str = "EasyOCR") -> tuple[OCRResult, dict]:
    stages = preprocess_image(image)
    if engine == "EasyOCR":
        lines, low = _ocr_easyocr(stages["gray"])          # EasyOCR prefers grayscale
    else:
        lines, low = _ocr_tesseract(stages["binary"])
        if np.mean([c for _, c in lines] or [0]) < 0.6:    # retry on grayscale if binarising hurt
            lines2, low2 = _ocr_tesseract(stages["gray"])
            if np.mean([c for _, c in lines2] or [0]) > np.mean([c for _, c in lines] or [0]):
                lines, low = lines2, low2
    return OCRResult(lines=lines, engine=engine, angle=stages["angle"], low_conf_words=low), stages


# ----------------------------------------------------------------------------- field parsing

SID_LABEL = re.compile(r"(?i)\b(?:stud[e3]n[t1]\s*[i1l|]\s*d|roll\s*(?:no|number)|reg(?:istration)?\s*no)\b\.?\s*[:;\-=]?\s*")
QID_LABEL = re.compile(r"(?i)\b(?:question\s*(?:id|no\.?|number)|q\.?\s*id|q\.?\s*no\.?)\s*[:;\-=]?\s*(q?\s*[.\-]?\s*[0-9Il|oO]{1,3})\b")
# "Question: Q5" / "Question No: Q5" (value must start with Q so "Question: What is..." is not caught)
QID_INLINE = re.compile(r"(?i)\bquestion\s*(?:id|no\.?|number)?\s*[:;\-=]?\s*(q\s*[.\-]?\s*[0-9Il|oO]{1,3})(?![a-z])")
FOOTER = re.compile(r"(?is)\b(?:end\s+of\s+(?:the\s+)?answer|signature|page\s+\d+\s+of\s+\d+)\b.*$")
Q_WITH_NUM = re.compile(r"(?i)^\s*(?:question|ques|qn|q)\s*\.?\s*([0-9Il|]{1,3})\s*[:.)\-]\s*(.*)$")
Q_PLAIN = re.compile(r"(?i)^\s*question\s*(?:text)?\s*[:;\-]\s*(.*)$")
ANS_LABEL = re.compile(r"(?i)(?:^|\n)\s*(?:student'?s?\s*)?(?:answer|ans)\s*\.?\s*[:;\-=]?\s*")
SID_VALUE = re.compile(r"\b([A-Za-z]{2,6}?)\s*[-_]?\s*([0-9OoIlSB]{2,6})\b")


def _clean_sid(prefix: str, digits: str) -> str:
    digits = digits.translate(str.maketrans({"O": "0", "o": "0", "I": "1", "l": "1", "S": "5", "B": "8"}))
    return f"{prefix.upper()}{digits}"


def parse_fields(text: str) -> dict:
    """Split OCR text into student_id, question_no, question, answer."""
    from .data_loader import normalise_qid
    from .preprocess import fix_ocr_text

    fields = {"student_id": "", "question_no": "", "question": "", "answer": ""}
    text = text.replace("\r", "")

    # answer = everything after the LAST answer label (avoids catching "answer" inside the question)
    ans_matches = list(ANS_LABEL.finditer(text))
    if ans_matches:
        a = ans_matches[-1]
        header, answer = text[:a.start()], text[a.end():]
    else:
        # fall back: answer starts after the first line that ends with '?'
        qm = re.search(r"\?\s*\n", text)
        header, answer = (text[:qm.end()], text[qm.end():]) if qm else (text, "")

    question_lines: list[str] = []
    in_question = False
    for line in header.split("\n"):
        line = line.strip()
        if not line:
            continue
        sid_m = SID_LABEL.search(line)
        if sid_m:
            v = SID_VALUE.search(line[sid_m.end():])
            if v:
                fields["student_id"] = _clean_sid(*v.groups())
            # a question may share the line ("Student ID: MCA001  Question 1: ...")
            rest = line[sid_m.end():][v.end():] if v else ""
            if not rest.strip():
                continue
            line = rest.strip()
        qid_m = QID_LABEL.search(line) or QID_INLINE.search(line)
        if qid_m:
            fields["question_no"] = normalise_qid(qid_m.group(1)) or ""
            line = (line[:qid_m.start()] + line[qid_m.end():]).strip(" :-")
            if not line:
                continue
        qn = Q_WITH_NUM.match(line)
        qp = Q_PLAIN.match(line)
        if qn:
            if not fields["question_no"]:
                fields["question_no"] = normalise_qid(qn.group(1)) or ""
            question_lines = [qn.group(2)]
            in_question = True
        elif qp:
            question_lines = [qp.group(1)]
            in_question = True
        elif in_question:
            question_lines.append(line)

    if not fields["student_id"]:
        v = SID_VALUE.search(header) or SID_VALUE.search(text)
        if v and not re.match(r"(?i)^q", v.group(1)):
            fields["student_id"] = _clean_sid(*v.groups())

    fields["question"] = fix_ocr_text(" ".join(question_lines).strip())
    answer = FOOTER.sub("", answer)
    answer = fix_ocr_text(re.sub(r"\s*\n\s*", " ", answer).strip())
    # loophole guard: drop the question if OCR glued it to the start of the answer
    q = fields["question"]
    if q and answer.lower().startswith(q.lower()[: max(10, len(q) // 2)]):
        answer = answer[len(q):].strip(" :-")
    fields["answer"] = answer
    return fields
