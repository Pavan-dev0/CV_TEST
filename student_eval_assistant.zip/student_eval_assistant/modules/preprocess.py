"""NLP preprocessing: lowercase, clean, tokenize, stop-word removal, stemming/lemmatization.

Works fully offline. If the NLTK WordNet corpus is installed it is used for lemmas and
extra synonyms; otherwise a built-in domain synonym list is used.
"""
from __future__ import annotations

import re
from functools import lru_cache

from nltk.stem import PorterStemmer  # needs no downloaded data

_stemmer = PorterStemmer()

# Negations are deliberately NOT stop words: "is not part of AI" must not earn the AI mark.
NEGATIONS = {"not", "no", "never", "cannot", "can't", "dont", "don't", "doesn't", "doesnt",
             "isn't", "isnt", "without", "neither", "nor", "none", "wont", "won't", "aren't"}

STOP_WORDS = {
    "a", "an", "the", "and", "or", "but", "if", "then", "so", "of", "to", "in", "on", "at", "by", "for",
    "with", "from", "into", "onto", "as", "is", "are", "was", "were", "be", "been", "being", "am",
    "it", "its", "this", "that", "these", "those", "there", "their", "they", "them", "he", "she", "we",
    "you", "i", "me", "my", "our", "your", "his", "her", "which", "who", "whom", "what", "when", "where",
    "why", "how", "do", "does", "did", "doing", "has", "have", "had", "having", "can", "could", "will",
    "would", "shall", "should", "may", "might", "must", "also", "such", "than", "too", "very", "just",
    "about", "over", "under", "again", "further", "once", "here", "all", "any", "both", "each", "few",
    "more", "most", "other", "some", "own", "same", "only", "up", "down", "out", "off", "through",
    "during", "before", "after", "above", "below", "between", "while", "because", "until", "etc",
    "eg", "ie", "called", "known", "refers", "refer", "means", "mean", "type", "kind", "way", "ways",
    "field", "branch", "used", "use", "uses", "using", "help", "helps", "helping",
    "enable", "enables", "enabling", "allow", "allows", "make", "makes", "making", "thing", "things",
}

# Domain synonym groups (NLP + CV). Each word maps to every other word in its group.
SYNONYM_GROUPS = [
    # NLP
    {"computer", "computers", "machine", "machines", "pc", "pcs"},
    {"understand", "understanding", "comprehend", "comprehension", "grasp"},
    {"interpret", "interpretation", "interpreting", "infer", "decode", "analyse", "analyze"},
    {"process", "processing", "handle", "handling", "manipulate"},
    {"language", "languages", "linguistic"},
    {"text", "texts", "paragraph", "paragraphs", "document", "documents", "string", "strings", "corpus"},
    {"human", "humans", "people", "person", "natural"},
    {"split", "splitting", "splits", "divide", "divides", "dividing", "break", "breaking",
     "separate", "separates", "separating", "partition", "partitioning"},
    {"unit", "units", "piece", "pieces", "chunk", "chunks", "token", "tokens", "part", "parts"},
    {"small", "smaller", "little", "tiny", "short", "shorter"},
    {"word", "words", "term", "terms"},
    {"phrase", "phrases", "expression", "expressions"},
    {"technique", "method", "approach", "task", "application", "tool"},
    {"opinion", "opinions", "view", "views", "attitude", "attitudes"},
    {"emotion", "emotions", "feeling", "feelings", "mood", "moods"},
    # Computer vision
    {"image", "images", "picture", "pictures", "photo", "photos", "frame", "frames"},
    {"resize", "resizing", "resized", "rescale", "rescaling", "scaling"},
    {"remove", "removal", "removing", "eliminate", "elimination", "reduce", "reduction", "delete", "discard"},
    {"filter", "filtering", "filters", "smoothing", "smooth", "blurring"},
    {"normalize", "normalise", "normalization", "normalisation", "normalized", "standardize", "standardization"},
    {"improve", "improves", "improving", "enhance", "enhancement", "increase", "better"},
    {"quality", "clarity"},
    {"architecture", "network", "model", "framework", "structure"},
    {"layer", "layers"},
    {"extract", "extraction", "extracts", "extracting"},
    {"feature", "features", "pattern", "patterns", "characteristic", "characteristics"},
    {"region", "regions", "area", "areas", "segment", "segments", "section", "sections", "zone", "zones",
     "part", "parts"},
    {"meaningful", "significant", "useful"},
    {"object", "objects", "item", "items"},
    # Machine learning / data science
    {"learn", "learning", "learns", "train", "trains", "training", "trained"},
    {"predict", "predicts", "prediction", "predictions", "forecast", "estimate"},
    {"output", "outputs", "result", "results", "target", "targets"},
    {"new", "unseen", "novel", "future", "unknown"},
    {"labelled", "labeled", "label", "labels", "annotated", "tagged"},
    {"data", "dataset", "examples", "samples"},
    {"identify", "identifies", "identifying", "identification", "detect", "detects", "detection",
     "find", "finds", "recognize", "recognise", "determine", "determines", "locate"},
    {"correct", "corrects", "correcting", "correction", "fix", "fixes", "fixing", "handle", "handling",
     "treat", "impute", "resolve", "rectify"},
    {"missing", "null", "empty", "blank", "nan"},
    {"value", "values", "entry", "entries"},
    {"duplicate", "duplicates", "duplicated", "repeated", "redundant"},
    {"record", "records", "row", "rows"},
    {"incorrect", "wrong", "invalid", "erroneous", "error", "errors", "inaccurate"},
    {"inconsistency", "inconsistencies", "inconsistent"},
]

ABBREVIATIONS = {
    "artificial intelligence": "ai",
    "natural language processing": "nlp",
    "machine learning": "ml",
    "computer vision": "cv",
    "optical character recognition": "ocr",
    "convolutional neural network": "cnn",
    "term frequency inverse document frequency": "tfidf",
    "named entity recognition": "ner",
    "part of speech": "pos",
    "deep learning": "dl",
}


def wordnet_available() -> bool:
    try:
        from nltk.corpus import wordnet
        wordnet.synsets("test")
        return True
    except Exception:
        return False


_WORDNET = wordnet_available()


# OCR confuses capital I with lowercase l in acronyms: "Al" -> "AI", "Ml" -> "ML"
OCR_FIXES = [(re.compile(r"\bAl\b"), "AI"), (re.compile(r"\bMl\b"), "ML"), (re.compile(r"\bNLl?P\b"), "NLP"),
             (re.compile(r"\bCNl\b"), "CNN"), (re.compile(r"\b0CR\b"), "OCR"),
             # "mode! used", "mode1", "mo|del": l read as ! 1 or | inside or at the end of a word
             (re.compile(r"(?<=[a-z])[!|](?=\s+[a-z])"), "l"), (re.compile(r"(?<=[a-z])[1|](?=[a-z])"), "l"),
             (re.compile(r"(?<=[a-z])0(?=[a-z])"), "o")]


def fix_ocr_text(text: str) -> str:
    for pattern, repl in OCR_FIXES:
        text = pattern.sub(repl, text)
    return text


def clean_text(text: str) -> str:
    """Lowercase, unify quotes/dashes, drop special characters but keep apostrophes in negations."""
    text = str(text).lower()
    text = text.replace("’", "'").replace("‘", "'").replace("-", " ").replace("/", " ")
    text = re.sub(r"[^a-z0-9'\s.?!]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+(?:'[a-z]+)?", clean_text(text))


def remove_stopwords(tokens: list[str]) -> list[str]:
    return [t for t in tokens if t not in STOP_WORDS or t in NEGATIONS]


@lru_cache(maxsize=20000)
def stem(word: str) -> str:
    return _stemmer.stem(word)


@lru_cache(maxsize=20000)
def lemma(word: str) -> str:
    if _WORDNET:
        from nltk.stem import WordNetLemmatizer
        lm = WordNetLemmatizer()
        return lm.lemmatize(lm.lemmatize(word, "n"), "v")
    return word[:-1] if len(word) > 3 and word.endswith("s") and not word.endswith("ss") else word


@lru_cache(maxsize=20000)
def synonyms(word: str) -> frozenset[str]:
    """Stems of all synonyms of `word` (including itself)."""
    out = {stem(word)}
    for group in SYNONYM_GROUPS:
        if word in group or stem(word) in {stem(g) for g in group}:
            out |= {stem(g) for g in group}
    if _WORDNET:
        from nltk.corpus import wordnet
        for syn in wordnet.synsets(word)[:3]:          # top senses only, to avoid drift
            for l in syn.lemmas()[:4]:
                name = l.name().lower()
                if "_" not in name:
                    out.add(stem(name))
    return frozenset(out)


def sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?;])\s+|\n+", str(text).strip())
    return [p.strip() for p in parts if len(p.strip()) > 2]


def preprocess(text: str) -> dict:
    """Full Step-4 pipeline, returning every stage so the UI can show it."""
    tokens = tokenize(text)
    content = remove_stopwords(tokens)
    return {
        "lower": str(text).lower(),
        "cleaned": clean_text(text),
        "tokens": tokens,
        "without_stopwords": content,
        "lemmas": [lemma(t) for t in content],
        "stems": [stem(t) for t in content],
        "clean_string": " ".join(lemma(t) for t in content),
    }
