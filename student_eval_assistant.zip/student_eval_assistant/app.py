"""Intelligent Student Assignment Evaluation Assistant - Streamlit app.

Run:  streamlit run app.py
"""
from __future__ import annotations

import hashlib
import io
import os
from pathlib import Path

import pandas as pd
import streamlit as st
from PIL import Image

from modules.data_loader import DataError, load_dataset
from modules.ocr import available_engines, run_ocr, parse_fields
from modules.pipeline import concept_table, evaluate_fields, report_row
from modules.scorer import Options, get_semantic_model

ROOT = Path(__file__).parent
DEFAULT_DATA = ROOT / "data"
LOG_FILE = ROOT / "results" / "evaluation_log.csv"

st.set_page_config(page_title="Assignment Evaluation Assistant", page_icon="📝", layout="wide")


# ----------------------------------------------------------------------------- cached helpers

@st.cache_data(show_spinner=False)
def cached_dataset(q_bytes: bytes, r_bytes: bytes, a_bytes: bytes | None):
    return load_dataset(io.BytesIO(q_bytes), io.BytesIO(r_bytes), io.BytesIO(a_bytes) if a_bytes else None)


@st.cache_data(show_spinner=False)
def cached_ocr(image_bytes: bytes, engine: str):
    ocr, stages = run_ocr(Image.open(io.BytesIO(image_bytes)), engine)
    return ocr, stages


@st.cache_resource(show_spinner="Loading the semantic similarity model ...")
def semantic_available() -> bool:
    return get_semantic_model() is not None


def read_bytes(path: Path) -> bytes | None:
    return path.read_bytes() if path.exists() else None


# ----------------------------------------------------------------------------- sidebar: data + settings

st.sidebar.title("Settings")
st.sidebar.subheader("Faculty files")
data_dir = Path(st.sidebar.text_input("Dataset folder", str(DEFAULT_DATA)))
up_q = st.sidebar.file_uploader("questions.csv (optional override)", type="csv")
up_r = st.sidebar.file_uploader("marking_rubric.csv (optional override)", type="csv")

q_bytes = up_q.getvalue() if up_q else read_bytes(data_dir / "questions.csv")
r_bytes = up_r.getvalue() if up_r else read_bytes(data_dir / "marking_rubric.csv")
a_bytes = read_bytes(data_dir / "student_answers.csv")      # validation tab only

if not q_bytes or not r_bytes:
    st.error("questions.csv and marking_rubric.csv were not found. Set the dataset folder or upload them.")
    st.stop()
try:
    dataset = cached_dataset(q_bytes, r_bytes, a_bytes)
except DataError as e:
    st.error(f"Problem in the faculty files: {e}")
    st.stop()
st.sidebar.success(f"{len(dataset.questions)} questions, {len(dataset.rubric)} rubric concepts loaded")
for w in dataset.warnings:
    st.sidebar.warning(w)

st.sidebar.subheader("OCR")
tess_cmd = st.sidebar.text_input("Tesseract path (Windows only, if not on PATH)",
                                 os.environ.get("TESSERACT_CMD", ""))
if tess_cmd:
    import pytesseract
    pytesseract.pytesseract.tesseract_cmd = tess_cmd
engines = available_engines()
if not engines:
    st.error("No OCR engine found. Install EasyOCR (`pip install easyocr`) or Tesseract.")
    st.stop()
engine = st.sidebar.radio("OCR engine", engines, horizontal=True)

st.sidebar.subheader("Marking")
partial = st.sidebar.toggle("Half marks for partly covered concepts", value=False)
gate = st.sidebar.toggle("Withhold marks for off-topic answers", value=True)
use_sem = st.sidebar.toggle("Semantic similarity (sentence-transformers)", value=False,
                            help="Needs `pip install sentence-transformers` and internet on first run.")
if use_sem and not semantic_available():
    st.sidebar.info("sentence-transformers is not available - using keyword, synonym and TF-IDF matching.")
    use_sem = False
options = Options(partial_marks=partial, use_semantic=use_sem, relevance_gate=gate)

# ----------------------------------------------------------------------------- header

st.title("📝 Intelligent Student Assignment Evaluation Assistant")
st.caption("OCR + NLP preliminary marking. **All marks are preliminary and must be reviewed by faculty.**")
tab_eval, tab_val, tab_log = st.tabs(["Evaluate answer sheet", "Validate on dataset", "Evaluation log"])

# ============================================================================= TAB 1: evaluate one image
def evaluate_tab():
    st.session_state.setdefault("run_id", 0)
    run = st.session_state["run_id"]

    # ---------------- Step 1
    st.header("Step 1 – Upload student answer image")
    c_up, c_pick = st.columns([3, 2])
    upload = c_up.file_uploader("Answer-sheet image", type=["png", "jpg", "jpeg", "bmp", "tif", "tiff"],
                                key=f"upload_{run}")
    samples = sorted((data_dir / "answer_images").glob("*.*")) if (data_dir / "answer_images").exists() else []
    pick = c_pick.selectbox("…or pick a dataset image", ["—"] + [p.name for p in samples], key=f"pick_{run}")

    image_bytes = upload.getvalue() if upload else (
        (data_dir / "answer_images" / pick).read_bytes() if pick != "—" else None)
    if image_bytes is None:
        st.info("Upload an answer-sheet image to start.")
        return

    with st.spinner(f"Reading the sheet with {engine} ..."):
        ocr, stages = cached_ocr(image_bytes, engine)
    parsed = parse_fields(ocr.text)

    # editable copies of the OCR fields (faculty can correct OCR mistakes)
    key = f"{run}_{hashlib.md5(image_bytes).hexdigest()[:10]}_{engine}"
    if st.session_state.get("fields_key") != key:
        st.session_state["fields_key"] = key
        for k, v in parsed.items():
            st.session_state[f"f_{k}"] = v

    c_img, c_det = st.columns([3, 2])
    c_img.image(image_bytes, caption="Uploaded answer sheet", width="stretch")
    with c_det:
        st.subheader("Identified student details")
        st.metric("Student ID", st.session_state["f_student_id"] or "not found")
        st.metric("Question number", st.session_state["f_question_no"] or "not found")
        if not parsed["student_id"] or not parsed["question_no"]:
            st.warning("OCR could not read every field - correct it in Step 2.")

    # ---------------- Step 2
    st.header("Step 2 – Extract text using OCR")
    c1, c2, c3 = st.columns(3)
    c1.metric("OCR engine", ocr.engine)
    c2.metric("Mean OCR confidence", f"{ocr.mean_conf:.0%}")
    c3.metric("Deskew angle", f"{ocr.angle:.1f}°")
    if ocr.mean_conf < 0.6:
        st.warning("Low OCR confidence - check the extracted text carefully.")
    if ocr.low_conf_words:
        st.caption("Low-confidence words: " + ", ".join(ocr.low_conf_words[:20]))
    with st.expander("Raw OCR text and preprocessed image"):
        st.code(ocr.text or "(no text found)", language=None)
        st.image(stages["binary"], caption="After grayscale, denoise, deskew and threshold", width="stretch")

    st.markdown("**Extracted fields** – edit here if OCR made a mistake; evaluation updates automatically.")
    e1, e2 = st.columns([1, 1])
    e1.text_input("Student ID", key="f_student_id")
    e2.text_input("Question number", key="f_question_no")
    st.text_input("Question", key="f_question")
    st.text_area("Student answer", key="f_answer", height=110)
    fields = {k: st.session_state[f"f_{k}"] for k in parsed}
    if fields != parsed:
        st.info("Evaluating the faculty-corrected text, not the raw OCR output.")

    result = evaluate_fields(fields, dataset, options)
    q, ev, fb = result["question"], result["evaluation"], result["feedback"]

    # ---------------- Step 3
    st.header("Step 3 – Identify the question")
    if ev is None:
        st.error(q["note"])
        return
    m1, m2, m3 = st.columns(3)
    m1.metric("Question ID", q["question_id"])
    m2.metric("Maximum marks", f"{q['max_marks']:g}")
    m3.metric("Matched by", q["method"])
    st.markdown(f"**Question:** {q['question']}")
    st.markdown(f"**Reference answer:** {q['reference_answer']}")
    if q.get("note"):
        st.warning(q["note"])

    # ---------------- Step 4
    st.header("Step 4 – Preprocess the student answer")
    pre = ev.preprocessing
    p1, p2 = st.columns(2)
    p1.markdown("**Lowercase**"); p1.write(pre["lower"])
    p2.markdown("**Punctuation / special characters removed**"); p2.write(pre["cleaned"])
    p1.markdown("**Tokens**"); p1.write(pre["tokens"])
    p2.markdown("**After stop-word removal** (negations kept)"); p2.write(pre["without_stopwords"])
    st.success(f"**Cleaned answer (lemmas):** {pre['clean_string']}")

    # ---------------- Step 5
    st.header("Step 5 – Compare with the reference answer")
    s1, s2, s3 = st.columns(3)
    s1.metric("TF-IDF cosine similarity", f"{ev.tfidf_similarity:.2f}")
    s2.metric("Semantic similarity", "off" if ev.semantic_similarity is None else f"{ev.semantic_similarity:.2f}")
    s3.metric("Concepts matched", f"{len(ev.covered)} / {len(ev.concepts)}")
    st.progress(min(ev.tfidf_similarity, 1.0), text="TF-IDF similarity")
    st.caption("Similarity is shown for information only. Marks come from rubric concepts (Step 6).")
    if ev.covered:
        st.markdown("**Matching concepts:** " + " · ".join(f"`{c.concept}` ({c.method})" for c in ev.covered))

    # ---------------- Step 6
    st.header("Step 6 – Evaluate using the marking rubric")
    table = pd.DataFrame(concept_table(result))
    st.dataframe(table, hide_index=True, width="stretch",
                 column_config={"Awarded": st.column_config.NumberColumn(format="%.1f")})
    st.metric("Preliminary marks", f"{ev.total:g} / {ev.max_marks:g}", help=f"Category: {ev.category}")

    # ---------------- Step 7
    st.header("Step 7 – Feedback")
    f1, f2 = st.columns(2)
    f1.markdown("**✅ Concepts covered**")
    f1.write("\n".join(f"- {c}" for c in fb["covered"]) or "None")
    if fb["partial"]:
        f1.markdown("**🟡 Partly covered**")
        f1.write("\n".join(f"- {c}" for c in fb["partial"]))
    f2.markdown("**❌ Concepts missing**")
    f2.write("\n".join(f"- {c}" for c in fb["missing"]) or "None")
    st.info(f"**Feedback:** {fb['summary']}\n\n**Suggestion:** {fb['suggestion']}")
    for flag in fb["flags"]:
        st.warning(flag)

    # ---------------- Step 8
    st.header("Step 8 – Evaluation report")
    with st.container(border=True):
        r1, r2, r3, r4 = st.columns(4)
        r1.metric("Student ID", fields["student_id"] or "—")
        r2.metric("Question ID", q["question_id"])
        r3.metric("Preliminary marks", f"{ev.total:g} / {ev.max_marks:g}")
        r4.metric("Category", ev.category)
        st.markdown(f"**Concepts covered:** {', '.join(fb['covered']) or 'None'}")
        st.markdown(f"**Concepts missing:** {', '.join(fb['missing']) or 'None'}")
        st.markdown(f"**Feedback:** {fb['summary']}")
        st.markdown(f"**Suggestion:** {fb['suggestion']}")
        st.caption("Status: PRELIMINARY – pending faculty review")

    st.subheader("Faculty review")
    v1, v2 = st.columns([1, 2])
    final = v1.number_input("Final marks", 0.0, float(ev.max_marks), float(ev.total), 0.5, key=f"final_{key}")
    reviewer = v2.text_input("Reviewed by", key=f"rev_{key}")
    remarks = st.text_input("Faculty remarks (optional)", key=f"rem_{key}")
    row = report_row(fields, result, final if reviewer else None, reviewer, remarks)

    b1, b2, b3 = st.columns(3)
    if b1.button("💾 Save to evaluation log", type="primary", disabled=not reviewer,
                 help="Enter the reviewer name to save."):
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame([row]).to_csv(LOG_FILE, mode="a", header=not LOG_FILE.exists(), index=False)
        st.success(f"Saved to {LOG_FILE.relative_to(ROOT)}")
    b2.download_button("⬇️ Download report (CSV)", pd.DataFrame([row]).to_csv(index=False),
                       file_name=f"report_{fields['student_id'] or 'student'}_{q['question_id']}.csv")
    if b3.button("🔄 Evaluate another image"):
        st.session_state["run_id"] += 1
        st.session_state.pop("fields_key", None)
        st.rerun()


with tab_eval:
    evaluate_tab()

# ============================================================================= TAB 2: validation
with tab_val:
    st.header("Validate against student_answers.csv")
    st.write("Runs OCR and evaluation on every dataset image, then compares with the benchmark file. "
             "`student_answers.csv` is used **only** for this comparison, never as evaluation input.")
    if dataset.student_answers is None:
        st.warning(f"student_answers.csv not found in {data_dir}.")
    elif st.button("▶ Run validation", type="primary"):
        from validate import run_validation, summarise
        bar = st.progress(0.0)
        df = run_validation(dataset, data_dir, engine, options, progress=lambda p, m: bar.progress(p, text=m))
        st.session_state["validation"] = df
    if "validation" in st.session_state:
        df = st.session_state["validation"]
        from validate import summarise
        cols = st.columns(4)
        for i, (k, v) in enumerate(summarise(df).items()):
            cols[i % 4].metric(k, v)
        st.dataframe(df[["image", "ocr_student_id", "ocr_question_id", "ocr_accuracy", "expected_marks",
                         "predicted_marks", "difference", "category", "ocr_answer", "flags"]],
                     hide_index=True, width="stretch")
        st.download_button("⬇️ Download validation report", df.to_csv(index=False), "validation_report.csv")

# ============================================================================= TAB 3: log
with tab_log:
    st.header("Saved evaluations")
    if LOG_FILE.exists():
        log = pd.read_csv(LOG_FILE)
        st.dataframe(log, hide_index=True, width="stretch")
        st.download_button("⬇️ Download log", log.to_csv(index=False), "evaluation_log.csv")
    else:
        st.info("No evaluations saved yet. Review an evaluation and click **Save to evaluation log**.")
