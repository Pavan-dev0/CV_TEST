# Intelligent Student Assignment Evaluation Assistant

A Streamlit app that reads a student's answer-sheet image with OCR, finds the question, compares the answer
with the faculty reference answer and rubric, and gives **preliminary** marks plus feedback for faculty to review.

```
Image → OCR (EasyOCR / Tesseract) → field extraction → question lookup → NLP preprocessing
      → similarity (TF-IDF) + rubric concept matching → marks → feedback → report → faculty review
```

## Results on the provided dataset (24 images)

| Measure | Result |
|---|---|
| Student ID read correctly | 100% |
| Question identified correctly | 100% |
| OCR answer accuracy (vs `student_answers.csv`) | 100% |
| Marks exactly equal to benchmark | 71% (17 / 24) |
| Marks within ±1 of benchmark | 100% |
| Mean absolute error | 0.29 marks |
| Irrelevant answers given 0 | 8 / 8 |

Measured with Tesseract and default settings (`python validate.py`). With half marks turned on (`--partial`)
the error drops to 0.25. With default settings the system never gave more marks than the benchmark, and every
difference was 1 mark or less. When it does differ, it is stricter: for example, it does not treat "known answers" as "labelled data".

## Setup

Use Python 3.10 – 3.12.

```bash
python -m venv venv
venv\Scripts\activate            # Windows   (macOS/Linux: source venv/bin/activate)
pip install -r requirements.txt
```

The app needs at least one OCR engine:

* **EasyOCR** is installed by `requirements.txt`. It downloads a model of about 100 MB the first time it runs, so you need internet once.
* **Tesseract** is optional and faster. Install the program first:
  * Windows: [UB-Mannheim installer](https://github.com/UB-Mannheim/tesseract/wiki). If it isn't on PATH, put its path (`C:\Program Files\Tesseract-OCR\tesseract.exe`) in the app sidebar.
  * Ubuntu: `sudo apt install tesseract-ocr`
  * macOS: `brew install tesseract`

## Run

```bash
streamlit run app.py          # the app: Evaluate, Validate, Evaluation log tabs
python validate.py            # command-line validation on all 24 images
python validate.py --engine Tesseract --partial
```

To evaluate a sheet, upload an image in the **Evaluate answer sheet** tab, or pick one from the dataset list. Steps 1–8 from the
brief appear in order on that page. Faculty can correct any OCR field, and the marks update straight away. To save a result, they enter a reviewer
name, adjust the final marks if needed, and click **Save to evaluation log**.

## Project structure

```
app.py                  Streamlit UI (Steps 1–8, validation tab, evaluation log)
validate.py             Batch validation against student_answers.csv
modules/
  data_loader.py        Loads/validates the CSVs (flexible column names, rubric total check)
  ocr.py                OpenCV preprocessing, EasyOCR/Tesseract, field parsing
  lookup.py             Question lookup by ID, fallback by question text
  preprocess.py         Lowercase, clean, tokenize, stop words, lemmas, synonyms, OCR fixes
  scorer.py             TF-IDF similarity, rubric concept matching, marks, relevance checks
  feedback.py           Feedback text and improvement suggestion
  pipeline.py           Ties the steps together; report record
data/                   The hackathon dataset (questions, rubric, answers, images)
results/                validation_report.csv, evaluation_log.csv (created when you run)
```

## How it works

**1. Image cleaning (Computer Vision).** The image is converted to grayscale, upscaled to about 1600 px wide, denoised,
deskewed using the angle of the text pixels, and then adaptively thresholded.

**2. OCR and field extraction.** The OCR words are grouped into lines. Regular expressions then find the labels
`Student ID`, `Question: Q5` and `Student Answer:`. They tolerate common OCR slips such as `Ql` for Q1, `lD` for ID and `MCAOO1` for MCA001.
The answer is everything after the answer label, with the `End of answer` footer removed. A small fix-up step repairs
common OCR errors, such as `Al` for AI and `mode!` for model.

**3. Question identification.** The question ID is normalised (`Q.1`, `Question 1`, `Ql` all become `Q1`) and looked up in
`questions.csv`. If the ID can't be read, the app fuzzy-matches the question text instead.

**4. Preprocessing.** The text is lowercased, punctuation and special characters are removed, and it is tokenized. Stop words are removed,
but negations such as "not" and "never" are kept. Finally, words are lemmatized (for display) and stemmed (for matching).

**5. Comparison.** TF-IDF cosine similarity with the reference answer uses unigrams and bigrams. Its IDF is fitted on all the reference
answers, so common words carry little weight. If sentence-transformers is installed, a semantic similarity score is also shown.
**Similarity never awards marks.** It is only used to warn about off-topic answers.

**6. Rubric concept matching.** This step gives the marks. Each rubric row is checked separately:

* **Alternatives:** `model learns / trains` becomes "model learns" OR "trains". `AI` and `artificial intelligence` are treated as the same.
* **Rule:** a one-word concept needs that word. A two-word concept needs both words. A concept of three or more words needs its key word plus two-thirds of the rest. The words must be in the same sentence.
* **Pass 1 – exact matches:** the same word stem, for example "identifies" and "identifying".
* **Pass 2 – synonyms and typos:** a domain synonym list such as "divides" = "splitting" or "fixes" = "correcting", plus OCR typo tolerance. A word already used as exact evidence for one concept can't earn a second concept.
* **Pass 3 (optional):** sentence-embedding similarity.
* **Result:** each concept is marked *covered*, *partial* (half marks if that option is on), *missing* or *negated*.

**7. Feedback.** Feedback is built from the covered, partial and missing concepts, plus one concrete suggestion and any review flags.

**8. Report and faculty review.** Every screen labels the marks as preliminary. Faculty can override the marks and add remarks, and each save
is logged with the reviewer's name.

## Loopholes handled

| Risk | How the app handles it |
|---|---|
| OCR misreads (`Ql`, `Al`, `mode!`, `MCAOO1`) | Character fixes, tolerant regex, editable fields, confidence shown |
| Question words counted as answer | Answer cut after the answer label; the answer's leading subject ("Image segmentation divides…") is not used as evidence |
| Irrelevant answer with one keyword ("AI is used in robotics…") | Relevance check: ≤1 concept and low similarity → 0 marks with a flag |
| Answer to a different question | Flag when the answer is closer to another question's reference |
| Negation ("not part of AI") | Negated concepts get 0 marks and are flagged |
| Keyword stuffing | Answers that are just a list of keywords are flagged for review |
| One phrase earning two concepts | A word can't be reused through synonyms once it is another concept's exact evidence |
| "machine learning" read as "machines" | Fixed terms are not split into synonyms |
| CSV differences | Flexible column names, BOM handling, rubric total checked against max marks |
| `student_answers.csv` misuse | Used only in `validate.py` / Validation tab |

## Limits

* The dataset images are printed text. Handwriting works better with EasyOCR than with Tesseract, but it still needs faculty checking.
* The synonym list is tuned for NLP, CV, ML and data-science questions. For a new subject, add synonyms to `SYNONYM_GROUPS`
  in `modules/preprocess.py`, or add an optional `keywords` column to the rubric (separate entries with `;`).
* Marks are preliminary. Faculty review is part of the workflow, not an extra.
