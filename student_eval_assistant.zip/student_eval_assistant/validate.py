"""Validation: run the full image pipeline on every answer image and compare with student_answers.csv.

student_answers.csv is used ONLY here, to measure OCR accuracy and marking agreement -
never as input to the evaluation.

Usage:
    python validate.py                       # EasyOCR if installed, else Tesseract
    python validate.py --engine Tesseract --partial
"""
from __future__ import annotations

import argparse
from difflib import SequenceMatcher
from pathlib import Path

import pandas as pd

from modules.data_loader import load_dataset, normalise_qid
from modules.ocr import available_engines
from modules.pipeline import evaluate_fields, read_sheet
from modules.preprocess import clean_text
from modules.scorer import Options

ROOT = Path(__file__).parent


def find_image(row, data_dir: Path) -> Path | None:
    for cand in [row["image"], f"answer_images/{row['student_id']}_{row['question_id']}.png"]:
        if cand and (data_dir / cand).exists():
            return data_dir / cand
    return None


def run_validation(dataset, data_dir: Path, engine: str, options: Options, progress=None) -> pd.DataFrame:
    rows = []
    total = len(dataset.student_answers)
    for i, r in dataset.student_answers.iterrows():
        img = find_image(r, data_dir)
        if progress:
            progress(i / total, f"{r['student_id']} {r['question_id']}")
        if img is None:
            rows.append({"image": "(missing)", "student_id": r["student_id"], "question_id": r["question_id"]})
            continue
        sheet = read_sheet(img, engine)                         # answer comes from the IMAGE
        f = sheet["fields"]
        res = evaluate_fields(f, dataset, options)
        ev = res["evaluation"]
        ocr_acc = SequenceMatcher(None, clean_text(f["answer"]), clean_text(r["answer"])).ratio()
        rows.append({
            "image": img.name,
            "student_id": r["student_id"],
            "ocr_student_id": f["student_id"],
            "id_ok": f["student_id"] == r["student_id"],
            "question_id": r["question_id"],
            "ocr_question_id": normalise_qid(f["question_no"]) or "",
            "qid_ok": res["question"].get("question_id") == r["question_id"],
            "ocr_answer": f["answer"],
            "ocr_accuracy": round(ocr_acc, 3),
            "expected_marks": r["expected_marks"],
            "predicted_marks": ev.total if ev else None,
            "difference": (ev.total - r["expected_marks"]) if ev else None,
            "category": ev.category if ev else "",
            "flags": " | ".join(ev.flags) if ev else "question not identified",
        })
    if progress:
        progress(1.0, "done")
    return pd.DataFrame(rows)


def summarise(df: pd.DataFrame) -> dict:
    ok = df.dropna(subset=["predicted_marks"])
    return {
        "Images evaluated": len(ok),
        "Student ID read correctly": f"{ok['id_ok'].mean():.0%}",
        "Question identified correctly": f"{ok['qid_ok'].mean():.0%}",
        "Mean OCR answer accuracy": f"{ok['ocr_accuracy'].mean():.1%}",
        "Marks exactly equal to benchmark": f"{(ok['difference'] == 0).mean():.0%}",
        "Marks within +/-1 of benchmark": f"{(ok['difference'].abs() <= 1).mean():.0%}",
        "Mean absolute error (marks)": f"{ok['difference'].abs().mean():.2f}",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(ROOT / "data"))
    ap.add_argument("--engine", default=None, choices=["EasyOCR", "Tesseract"])
    ap.add_argument("--partial", action="store_true", help="award half marks for partly covered concepts")
    ap.add_argument("--no-semantic", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "results" / "validation_report.csv"))
    args = ap.parse_args()

    data = Path(args.data)
    ds = load_dataset(data / "questions.csv", data / "marking_rubric.csv", data / "student_answers.csv")
    for w in ds.warnings:
        print("WARNING:", w)
    engines = available_engines()
    if not engines:
        raise SystemExit("No OCR engine found. Install EasyOCR (pip install easyocr) or Tesseract.")
    engine = args.engine or engines[0]
    opts = Options(partial_marks=args.partial, use_semantic=not args.no_semantic)
    print(f"OCR engine: {engine}")

    df = run_validation(ds, data, engine, opts, progress=lambda p, m: print(f"  [{p:4.0%}] {m}", end="\r"))
    print()
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out, index=False)
    pd.set_option("display.width", 200)
    print(df[["image", "ocr_student_id", "ocr_question_id", "ocr_accuracy", "expected_marks",
              "predicted_marks", "difference", "category"]].to_string(index=False))
    print()
    for k, v in summarise(df).items():
        print(f"{k:<34} {v}")
    print(f"\nFull report: {args.out}")


if __name__ == "__main__":
    main()
